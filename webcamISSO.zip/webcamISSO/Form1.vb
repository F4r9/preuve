﻿Public Class Form1
    Dim ELEMENT As String
    Private Sub Guna2HtmlLabel2_Click(sender As Object, e As EventArgs) Handles Guna2HtmlLabel2.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ELEMENT = ("webcam1")
        ProgressBar1.Hide()
        Timer1.Start()
        Guna2Panel1.Hide()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ELEMENT = ("webcam1")
        ProgressBar1.Increment(5)
        Guna2HtmlLabel2.Text = ("Connecting to server...")
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Guna2HtmlLabel2.Text = ("Connected to server.")
            Guna2Panel1.Show()
            Timer2.Start()
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Try
            PictureBox2.ImageLocation = WebBrowser1.Document.GetElementById(ELEMENT).GetAttribute("src")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Form2.Show()

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        ELEMENT = ("webcam1")
        ELEMENT = ("webcam1")
        ELEMENT = ("webcam1")
        ELEMENT = ("webcam1")
        ELEMENT = ("webcam1")
        ELEMENT = ("webcam1")
        WebBrowser1.Navigate("http://minside.dyndns.org:8080/home.html?src=1&mode=0")
        Timer3.Stop()
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        ELEMENT = ("webcam2")
        WebBrowser1.Navigate("http://minside.dyndns.org:8080/home.html?src=2&mode=0")
        Timer4.Stop()
    End Sub
End Class
